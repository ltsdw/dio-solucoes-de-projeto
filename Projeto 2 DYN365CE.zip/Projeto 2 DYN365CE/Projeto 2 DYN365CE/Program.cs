﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Projeto2DYN365CE
{
    class Program
    {
        static void Main(string[] args)
        {
            string username = Environment.GetEnvironmentVariable("D365_USERNAME");
            string password = Environment.GetEnvironmentVariable("D365_PASSWORD");
            string url = Environment.GetEnvironmentVariable("D365_URL");
            string appId = Environment.GetEnvironmentVariable("D365_APP_ID");
            string redirectUri = Environment.GetEnvironmentVariable("D365_REDIRECT_URI");
            string user = Environment.GetEnvironmentVariable("USERNAME");

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(url))
            {
                throw new InvalidOperationException("Variáveis de ambiente não configuradas corretamente.");
            }

            string connectionString = $@"
                AuthType=OAuth;
                Username={username};
                Password={password};
                SkipDiscovery=True;
                AppId={appId};
                RedirectUri={redirectUri};
                Url={url};
                TokenCacheStorePath=c:\Users\{user}\Desktop\MyTokenCache";

            CrmServiceClient crmServiceClient = _ToDeleteConnection.GetCrmServiceClient(connectionString);

            Console.WriteLine(connectionString);
            //_ToDeleteConnection.DeleteEntity(crmServiceClient, new Guid(""));
            //_ToDeleteConnection.Create(crmServiceClient);
            //_ToDeleteConnection.FetchXML(crmServiceClient);
        }
    }
}
