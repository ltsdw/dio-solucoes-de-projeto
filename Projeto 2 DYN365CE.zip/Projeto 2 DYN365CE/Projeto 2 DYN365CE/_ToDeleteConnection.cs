﻿using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Projeto2DYN365CE
{
    public static class _ToDeleteConnection
    {
        private static CrmServiceClient _crmServiceClient = null;

        public static CrmServiceClient GetCrmServiceClient(string connectionString)
        {
            if (_crmServiceClient != null)
            {
                return _crmServiceClient;
            }

            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            try
            {
                _crmServiceClient = new CrmServiceClient(connectionString);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Falha na autenticação: {e}");
            }

            return _crmServiceClient;
        }

        public static void FetchXML(CrmServiceClient crmServiceClient)
        {
            if (crmServiceClient == null)
            {
                throw new ArgumentException("CrmServiceCliet não pode ser nulo.");
            }

            string query = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                <entity name='account'>
                <attribute name='name' />
                <attribute name='telephone1' />
                <attribute name='accountid' />
                <attribute name='emailaddress1' />
                <order attribute='name' descending='false' />
                </entity>
                </fetch>";
            EntityCollection collection = crmServiceClient.RetrieveMultiple(new FetchExpression(query));

            foreach (var item in collection.Entities)
            {
                if (item.Attributes.Contains("name"))
                {
                    Console.WriteLine(item["name"]);
                }

                if (item.Attributes.Contains("telephone1"))
                {
                    Console.WriteLine(item["telephone1"]);
                }
            }
        }

        public static void Create(CrmServiceClient crmServiceClient)
        {
            if (crmServiceClient == null)
            {
                throw new ArgumentException("CrmServiceCliet não pode ser nulo.");
            }

            Guid newRecord = new Guid();
            Entity newEntity = new Entity("account");
            newEntity.Attributes.Add("name", $"Conta Criada em Treinamento - {DateTime.Now.ToString()}");
            newEntity.Attributes.Add("telephone1", "11985326471");
            newEntity.Attributes.Add("emailaddress1", "contato@provedor.com");
            newRecord = crmServiceClient.Create(newEntity);

            if (newRecord == Guid.Empty)
            {
                Console.WriteLine("newRecord não criado!");

                return;
            }

            Console.WriteLine("Id do Registro criado : " + newRecord);
        }

        public static void UpdateEntity(CrmServiceClient crmServiceClient, Guid guidAccount)
        {
            if (crmServiceClient == null)
            {
                throw new ArgumentException("CrmServiceCliet não pode ser nulo.");
            }

            Entity upEntity = new Entity("account", guidAccount);
            upEntity["name"] = "Conta de Update";
            upEntity["telephone1"] = "11978526941";
            upEntity["emailaddress1"] = "contato@meuprovedor.com";

            crmServiceClient.Update(upEntity);
        }

        public static void DeleteEntity(CrmServiceClient crmServiceClient, Guid guidAccount)
        {
            if (crmServiceClient == null)
            {
                throw new ArgumentException("CrmServiceCliet não pode ser nulo.");
            }

            var entityDelete = crmServiceClient.Retrieve("account", guidAccount, new ColumnSet("name"));

            if (entityDelete.Attributes.Count > 0)
            {
                crmServiceClient.Delete("account", guidAccount);
                Console.WriteLine("Conta excluída!");
            }
        }
    }
}
