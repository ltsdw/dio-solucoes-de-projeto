﻿using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PluginsTreinamento
{
    public class PluginAccountPreOperation : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context =
                (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory =
                (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService serviceAdmin = serviceFactory.CreateOrganizationService(null);
            ITracingService trace = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            if (!context.InputParameters.Contains("Target") && !(context.InputParameters["Target"] is Entity))
            {
                return;
            }

            Entity entityContext = (Entity)context.InputParameters["Target"];

            if (!(entityContext.LogicalName == "account" && entityContext.Attributes.Contains("telephone1")))
            {
                return;
            }

            string phone1 = entityContext["telephone1"].ToString();
            string fetchContact = @"<?xml version='1.0'?>" +
                "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>" +
                "<entity name='contact'>" +
                "<attribute name='fullname'/>" +
                "<attribute name='telephone1'/>" +
                "<attribute name='contactid'/>" +
                "<order descending='false' attribute='fullname'/>" +
                "<filter type='and'>" +
                "<condition attribute='telephone1' value='" + phone1 + "' operator='eq'/>" +
                "</filter>" +
                "</entity>" +
                "</fetch>";

            trace.Trace($"FetchContact: {fetchContact}");

            EntityCollection primaryContact = serviceAdmin.RetrieveMultiple(new FetchExpression(fetchContact));

            if (!(primaryContact.Entities.Count > 0))
            {
                return;
            }

            foreach (var entityContact in primaryContact.Entities)
            {
                entityContext["primarycontactid"] = new EntityReference("contact", entityContact.Id);
            }
        }
    }
}
