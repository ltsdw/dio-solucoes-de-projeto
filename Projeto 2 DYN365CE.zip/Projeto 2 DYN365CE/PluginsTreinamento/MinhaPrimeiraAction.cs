﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PluginsTreinamento
{
    public class MinhaPrimeiraAction : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context =
                (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory =
                (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService serviceAdmin = serviceFactory.CreateOrganizationService(null);

            ITracingService trace = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            trace.Trace("Minha Primeira Action executada com sucesso e criando Lead no Dataverse!");

            Entity entityLead = new Entity("lead");
            entityLead["subject"] = "Lead criado via Action";
            entityLead["firstname"] = "Primeiro Nome";
            entityLead["lastname"] = "Lastname Lead";
            entityLead["mobilephone"] = "920220720";
            entityLead["ownerid"] = new EntityReference("systemuser", context.UserId);
            Guid guidLead = serviceAdmin.Create(entityLead);
            trace.Trace("Lead criado: " + guidLead);
        }
    }
}
