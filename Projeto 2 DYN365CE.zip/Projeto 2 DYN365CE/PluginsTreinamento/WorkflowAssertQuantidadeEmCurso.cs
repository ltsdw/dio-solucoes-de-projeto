﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace PluginsTreinamento
{
    public class WorkflowAssertQuantidadeEmCurso : CodeActivity
    {
        [Output("output")]
        public OutArgument<string> output { get; set; }


        protected override void Execute(CodeActivityContext executionContext)
        {
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            ITracingService trace = executionContext.GetExtension<ITracingService>();
            Guid alunoXCursosId = context.PrimaryEntityId;
            Entity alunoXCursos = service.Retrieve("projeto2_alunoxcursos", alunoXCursosId, new ColumnSet("projeto2_alunolookup"));
            Guid guidAluno = alunoXCursos.GetAttributeValue<EntityReference>("projeto2_alunolookup").Id;
            string fetchCursosAtivosParaAluno = $@"
                <fetch version='1.0' mapping='logical' no-lock='false' distinct='false'>
                    <entity name='projeto2_alunoxcursos'>
                        <attribute name='statecode'/>
                        <attribute name='projeto2_alunoxcursosid'/>
                        <attribute name='projeto2_name'/>
                        <attribute name='createdon'/>
                        <order attribute='projeto2_name' descending='false'/>
                        <filter type='and'>
                            <condition attribute='projeto2_alunolookup' operator='eq' value='{guidAluno}'/>
                            <condition attribute='projeto2_emcurso' operator='eq' value='1'/>
                        </filter>
                    </entity>
                </fetch>
            ";
            EntityCollection entityNumeroDeCursosAtivosParaAluno = service.RetrieveMultiple(new FetchExpression(fetchCursosAtivosParaAluno));

            trace.Trace($"GUID do Aluno: {guidAluno}");
            trace.Trace($"Quantidade de cursos em que o aluno está cursando: {entityNumeroDeCursosAtivosParaAluno.Entities.Count}");

            if (entityNumeroDeCursosAtivosParaAluno.Entities.Count >= 2)
            {
                output.Set(executionContext, "Aluno excedeu limite de cursos ativos!");
                trace.Trace("Aluno excedeu limite de cursos ativos!");
                throw new InvalidPluginExecutionException("Aluno excedeu limite de cursos ativos!");
            }
        }
    }
}
