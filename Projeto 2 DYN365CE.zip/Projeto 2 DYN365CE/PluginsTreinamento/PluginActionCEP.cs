﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace PluginsTreinamento
{
    public class PluginActionCEP : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context =
                (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory =
                (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService serviceAdmin = serviceFactory.CreateOrganizationService(null);
            ITracingService trace = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            Object CEP = context.InputParameters["CEPInput"];
            string viaCEPAPIUrl = $"https://viacep.com.br/ws/{CEP}/json/";
            string result = string.Empty;

            trace.Trace($"Cep informado: {CEP}");

            using (WebClient client = new WebClient())
            {
                client.Headers[HttpRequestHeader.ContentType] = "application/json";
                client.Encoding = Encoding.UTF8;
                result = client.DownloadString(viaCEPAPIUrl);
            }

            context.OutputParameters["CEPResult"] = result;

            trace.Trace($"Resultado: {result}");
        }
    }
}
