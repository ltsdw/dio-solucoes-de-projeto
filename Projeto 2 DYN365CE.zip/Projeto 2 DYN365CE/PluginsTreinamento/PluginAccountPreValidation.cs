﻿using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PluginsTreinamento
{
    public class PluginAccountPreValidation : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context =
                (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory =
                (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService serviceAdmin = serviceFactory.CreateOrganizationService(null);
            ITracingService trace = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            Entity entityContext = null;

            if (context.InputParameters.Contains("Target"))
            {
                entityContext = (Entity)context.InputParameters["Target"];

                trace.Trace($"Entidade do Contexto: {entityContext.Attributes.Count}");

                if (entityContext == null)
                {
                    return;
                }

                if (!entityContext.Contains("telephone1"))
                {
                    throw new InvalidPluginExecutionException("Campo Telefone principal é obrigatório!!");
                }
            }
        }
    }
}
