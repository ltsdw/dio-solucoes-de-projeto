﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PluginsTreinamento
{
    public class PluginAccountPostOperation : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context =
                (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory =
                (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService serviceAdmin = serviceFactory.CreateOrganizationService(null);
            ITracingService trace = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            if (!(context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity))
            {
                return;
            }

            Entity entityContext = (Entity)context.InputParameters["Target"];

            if (!entityContext.Contains("websiteurl"))
            {
                throw new InvalidPluginExecutionException("Campo websiteurl é obrigatório!");
            }

            Entity task = new Entity("task");

            task.Attributes["ownerid"] = new EntityReference("systemuser", context.UserId);
            task.Attributes["regardingobjectid"] = new EntityReference("account", context.PrimaryEntityId);
            task.Attributes["subject"] = "Visite nosso site: " + entityContext["websiteurl"];
            task.Attributes["description"] = "Task criada via Plugin Post Operation";

            try
            {
                serviceAdmin.Create(task);

            }
            catch (InvalidPluginExecutionException e)
            {
                throw new InvalidPluginExecutionException($"Erro ocorrido: {e.Message}");
            }
        }
    }
}
